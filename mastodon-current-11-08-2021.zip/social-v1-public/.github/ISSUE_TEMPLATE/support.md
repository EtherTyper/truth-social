---
name: Support
about: Ask for help with your deployment

---

We primarily use GitHub as a bug and feature tracker. For usage questions, troubleshooting of deployments and other individual technical assistance, please use one of the resources below:

- https://discourse.joinmastodon.org
- #mastodon on irc.freenode.net
