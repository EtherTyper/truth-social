# Custom icons

- dashboard-filled.svg - Modified from Tabler icons, MIT  
- fediverse.svg - Modified from Wikipedia, CC0  
- gavel.svg - Created by ramsha61 for this project, MIT  
- home-squared.svg - Modified from Tabler icons, MIT  
- pen-plus.svg - Modified from Tabler icons, MIT  

Tabler: https://tabler-icons.io/  
Feather: https://feathericons.com/  
Fediverse logo: https://en.wikipedia.org/wiki/Fediverse#/media/File:Fediverse_logo_proposal.svg  
ramsha61: https://www.fiverr.com/ramsha61  
