import React from 'react';

const VerificationBadge = () => (
  <img src={require('icons/verified.svg')} className='h-4 w-4' alt='Verified' />
);

export default VerificationBadge;
