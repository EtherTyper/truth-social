import 'intersection-observer';
import 'requestidlecallback';
import objectFitImages from 'object-fit-images';

objectFitImages();
