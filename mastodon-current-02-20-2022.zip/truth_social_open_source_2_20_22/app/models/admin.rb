# frozen_string_literal: true

module Admin
  def self.table_name_prefix
    'admin_'
  end
end
