# frozen_string_literal: true

module Web
  def self.table_name_prefix
    'web_'
  end
end
